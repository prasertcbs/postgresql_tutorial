--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5
-- Dumped by pg_dump version 10.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.product DROP CONSTRAINT product_pkey;
ALTER TABLE ONLY public.movie DROP CONSTRAINT movie_pkey;
ALTER TABLE ONLY public.member DROP CONSTRAINT member_pkey;
ALTER TABLE ONLY public.drink DROP CONSTRAINT drink_pkey;
ALTER TABLE ONLY public.customer DROP CONSTRAINT customer_pkey;
ALTER TABLE ONLY public.applicant DROP CONSTRAINT applicant_pkey;
DROP TABLE public.province;
DROP TABLE public.product;
DROP TABLE public.movie;
DROP TABLE public.member;
DROP TABLE public.drink;
DROP TABLE public.customer;
DROP TABLE public.applicant;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: applicant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.applicant (
    app_id integer NOT NULL,
    name character varying(50) NOT NULL,
    skills character varying(50)[]
);


ALTER TABLE public.applicant OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    customer_id integer NOT NULL,
    fname character varying(50) NOT NULL,
    lname character varying(50)
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: drink; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.drink (
    product_id integer NOT NULL,
    name character varying(100),
    price numeric(8,2),
    is_recommend boolean
);


ALTER TABLE public.drink OWNER TO postgres;

--
-- Name: member; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.member (
    member_id integer NOT NULL,
    fname character varying(50) NOT NULL,
    email character varying[]
);


ALTER TABLE public.member OWNER TO postgres;

--
-- Name: movie; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.movie (
    movie_id integer NOT NULL,
    movie_title character varying(255),
    title_year integer,
    duration integer,
    content_rating character varying(255),
    budget numeric(12,0),
    gross numeric(12,0),
    genres character varying(255),
    imdb_score real,
    director_name character varying(255),
    actor_1_name character varying(255),
    actor_2_name character varying(255),
    actor_3_name character varying(255),
    country character varying(255)
);


ALTER TABLE public.movie OWNER TO postgres;

--
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product (
    product_id integer NOT NULL,
    name character varying(100) NOT NULL,
    price numeric(8,2) NOT NULL,
    is_recommend boolean
);


ALTER TABLE public.product OWNER TO postgres;

--
-- Name: province; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.province (
    p_id character varying(3),
    name character varying(50),
    name_en character varying(50),
    region character varying(2),
    area_km2 numeric(10,2)
);


ALTER TABLE public.province OWNER TO postgres;

--
-- Data for Name: applicant; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.applicant (app_id, name, skills) FROM stdin;
\.
COPY public.applicant (app_id, name, skills) FROM '$$PATH$$/2832.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (customer_id, fname, lname) FROM stdin;
\.
COPY public.customer (customer_id, fname, lname) FROM '$$PATH$$/2828.dat';

--
-- Data for Name: drink; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.drink (product_id, name, price, is_recommend) FROM stdin;
\.
COPY public.drink (product_id, name, price, is_recommend) FROM '$$PATH$$/2829.dat';

--
-- Data for Name: member; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.member (member_id, fname, email) FROM stdin;
\.
COPY public.member (member_id, fname, email) FROM '$$PATH$$/2831.dat';

--
-- Data for Name: movie; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.movie (movie_id, movie_title, title_year, duration, content_rating, budget, gross, genres, imdb_score, director_name, actor_1_name, actor_2_name, actor_3_name, country) FROM stdin;
\.
COPY public.movie (movie_id, movie_title, title_year, duration, content_rating, budget, gross, genres, imdb_score, director_name, actor_1_name, actor_2_name, actor_3_name, country) FROM '$$PATH$$/2833.dat';

--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product (product_id, name, price, is_recommend) FROM stdin;
\.
COPY public.product (product_id, name, price, is_recommend) FROM '$$PATH$$/2830.dat';

--
-- Data for Name: province; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.province (p_id, name, name_en, region, area_km2) FROM stdin;
\.
COPY public.province (p_id, name, name_en, region, area_km2) FROM '$$PATH$$/2834.dat';

--
-- Name: applicant applicant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.applicant
    ADD CONSTRAINT applicant_pkey PRIMARY KEY (app_id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (customer_id);


--
-- Name: drink drink_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.drink
    ADD CONSTRAINT drink_pkey PRIMARY KEY (product_id);


--
-- Name: member member_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_pkey PRIMARY KEY (member_id);


--
-- Name: movie movie_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movie
    ADD CONSTRAINT movie_pkey PRIMARY KEY (movie_id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (product_id);


--
-- PostgreSQL database dump complete
--

